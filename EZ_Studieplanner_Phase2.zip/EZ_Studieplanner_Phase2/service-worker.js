/* EZ Service Worker — Phase 2
 * Phase 3 will use the push event to deliver server-scheduled study reminders.
 */
const CACHE_NAME = 'ez-shell-v1';
const APP_SHELL = [
  './',
  './index.html',
  './ez-platform.js',
  './manifest.webmanifest'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if(request.method !== 'GET') return;

  const url = new URL(request.url);

  // App navigation: cached shell first, then network, then shell fallback.
  if(request.mode === 'navigate'){
    event.respondWith(
      caches.match('./index.html').then(cached =>
        cached || fetch(request).then(response => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put('./index.html', copy));
          return response;
        }).catch(() => caches.match('./index.html'))
      )
    );
    return;
  }

  // Same-origin app assets: cache first, then update in the background.
  if(url.origin === self.location.origin){
    event.respondWith(
      caches.match(request).then(cached => {
        const network = fetch(request).then(response => {
          if(response.ok){
            const copy = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
          }
          return response;
        }).catch(() => cached);
        return cached || network;
      })
    );
    return;
  }

  // External resources (Tailwind/fonts) are runtime-cached after first load.
  event.respondWith(
    caches.match(request).then(cached => cached || fetch(request).then(response => {
      if(response.ok && (url.protocol === 'https:' || url.protocol === 'http:')){
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
      }
      return response;
    }))
  );
});

self.addEventListener('push', event => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; }
  catch { payload = {body: event.data?.text?.() || ''}; }

  const title = payload.title || 'EZ — Studieplanner';
  const options = {
    body: payload.body || 'Je hebt een nieuwe studieherinnering.',
    icon: payload.icon || './icons/icon-192.png',
    badge: payload.badge || './icons/icon-192.png',
    tag: payload.tag || 'ez-study',
    renotify: Boolean(payload.renotify),
    data: {url: payload.url || './', ...(payload.data || {})},
    actions: Array.isArray(payload.actions) ? payload.actions : []
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = event.notification.data?.url || './';
  event.waitUntil(
    clients.matchAll({type:'window', includeUncontrolled:true}).then(list => {
      const existing = list.find(client => 'focus' in client);
      if(existing){
        existing.navigate(target);
        return existing.focus();
      }
      return clients.openWindow(target);
    })
  );
});
