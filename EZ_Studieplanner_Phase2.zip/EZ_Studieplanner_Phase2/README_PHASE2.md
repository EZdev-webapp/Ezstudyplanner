# EZ — Studieplanner · Phase 2

Phase 2 turns the existing EZ app into a PWA-ready architecture without changing the study-planning behavior.

## Files

- `index.html` — existing EZ UI/planner
- `ez-platform.js` — browser/PWA/platform boundary
- `service-worker.js` — app shell caching + future push handling
- `manifest.webmanifest` — installable PWA metadata
- `icons/` — app icons

## Phase 3 boundary

The future push backend only needs to connect to the interfaces already prepared in `ez-platform.js` and the `push` event in `service-worker.js`.

The planner still stores its main state in profile-based localStorage. Phase 2 additionally keeps a sync-ready IndexedDB snapshot containing the data relevant to planning/push scheduling.

No server, VAPID key, account system, or cloud sync is enabled yet. That is intentionally Phase 3 work.

## Deployment requirement

Service workers and Push API require a secure origin (HTTPS; localhost is also suitable for development). Opening `index.html` directly from `file://` will not enable the PWA layer.
