/* EZ Platform Layer — Phase 2
 * Keeps browser/PWA capabilities outside the main UI.
 * Phase 3 can connect the same interface to a real push backend without
 * changing the study planner UI.
 */
(function(){
  'use strict';

  const DB_NAME = 'ez-platform';
  const DB_VERSION = 1;
  const STORE = 'meta';

  function openDB(){
    return new Promise((resolve,reject)=>{
      if(!('indexedDB' in window)) return resolve(null);
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = ()=>{
        const db = req.result;
        if(!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = ()=>resolve(req.result);
      req.onerror = ()=>reject(req.error);
    });
  }

  async function dbSet(key,value){
    const db = await openDB();
    if(!db) return false;
    return new Promise(resolve=>{
      const tx = db.transaction(STORE,'readwrite');
      tx.objectStore(STORE).put(value,key);
      tx.oncomplete = ()=>{ db.close(); resolve(true); };
      tx.onerror = ()=>{ db.close(); resolve(false); };
    });
  }

  async function dbGet(key){
    const db = await openDB();
    if(!db) return null;
    return new Promise(resolve=>{
      const tx = db.transaction(STORE,'readonly');
      const req = tx.objectStore(STORE).get(key);
      req.onsuccess = ()=>resolve(req.result ?? null);
      req.onerror = ()=>resolve(null);
      tx.oncomplete = ()=>db.close();
    });
  }

  const Platform = {
    version: 'phase2',
    swRegistration: null,

    isSecureContext(){
      return window.isSecureContext === true;
    },

    isInstalled(){
      return window.matchMedia?.('(display-mode: standalone)').matches ||
        window.navigator.standalone === true;
    },

    supportsServiceWorker(){
      return 'serviceWorker' in navigator && this.isSecureContext();
    },

    supportsPush(){
      return this.supportsServiceWorker() && 'PushManager' in window && 'Notification' in window;
    },

    async registerServiceWorker(){
      if(!this.supportsServiceWorker()) return null;
      try{
        this.swRegistration = await navigator.serviceWorker.register('./service-worker.js', {scope:'./'});
        await navigator.serviceWorker.ready;
        return this.swRegistration;
      }catch(err){
        console.warn('EZ: service worker registreren mislukt', err);
        return null;
      }
    },

    async requestNotificationPermission(){
      if(!('Notification' in window)) return 'unsupported';
      if(Notification.permission === 'granted') return 'granted';
      if(Notification.permission === 'denied') return 'denied';
      return Notification.requestPermission();
    },

    async getPushSubscription(){
      const reg = this.swRegistration || await navigator.serviceWorker?.ready;
      if(!reg?.pushManager) return null;
      return reg.pushManager.getSubscription();
    },

    // Phase 3 supplies the server's VAPID public key and endpoint.
    async subscribeToPush(vapidPublicKey){
      if(!this.supportsPush() || !vapidPublicKey) return null;
      const permission = await this.requestNotificationPermission();
      if(permission !== 'granted') return null;
      const reg = this.swRegistration || await navigator.serviceWorker.ready;
      let subscription = await reg.pushManager.getSubscription();
      if(!subscription){
        subscription = await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: this.urlBase64ToUint8Array(vapidPublicKey)
        });
      }
      await dbSet('pushSubscription', subscription.toJSON());
      return subscription;
    },

    async unsubscribeFromPush(){
      const subscription = await this.getPushSubscription();
      if(!subscription) return true;
      const ok = await subscription.unsubscribe();
      if(ok) await dbSet('pushSubscription', null);
      return ok;
    },

    // A stable boundary for Phase 3. The planner can continue using localStorage
    // while a future API syncs only the data that needs to reach the push server.
    async prepareSyncSnapshot(profileName, state){
      const snapshot = {
        schemaVersion: 1,
        profile: profileName || null,
        generatedAt: new Date().toISOString(),
        tests: Array.isArray(state?.tests) ? state.tests : [],
        grades: Array.isArray(state?.grades) ? state.grades : [],
        subjects: Array.isArray(state?.subjects) ? state.subjects : [],
        studySessions: Array.isArray(state?.studySessions) ? state.studySessions : [],
        settings: state?.settings || {}
      };
      await dbSet('latestSyncSnapshot', snapshot);
      return snapshot;
    },

    async getLatestSyncSnapshot(){
      return dbGet('latestSyncSnapshot');
    },

    urlBase64ToUint8Array(base64String){
      const padding = '='.repeat((4 - base64String.length % 4) % 4);
      const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
      const rawData = atob(base64);
      return Uint8Array.from([...rawData].map(char => char.charCodeAt(0)));
    }
  };

  window.EZPlatform = Platform;

  window.addEventListener('load', ()=>{
    Platform.registerServiceWorker();
  });
})();
